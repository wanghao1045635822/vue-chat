export default class EngineCallback{
    onReceiveCall(callSession){}

    shouldStartRing(isIncomming){}

    shouldSopRing(){}
}