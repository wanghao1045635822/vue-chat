export default class OnReceiverMessageListener {
    onReceiveMessage(protoMessage){

    }
}