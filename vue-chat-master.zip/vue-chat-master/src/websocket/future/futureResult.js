export default class FutureResult {
    code;
    result;

    constructor(code, result){
        this.code = code
        this.result = result
    }
}