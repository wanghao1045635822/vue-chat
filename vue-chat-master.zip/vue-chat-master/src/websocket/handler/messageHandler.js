export default class MessageHandler{
    match(signal){
        return false;
    }

    processMessage(data){

    }
}