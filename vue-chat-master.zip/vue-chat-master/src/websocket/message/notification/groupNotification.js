import NotificationMessageContent from "./notificationMessageContent";

export default class GroupNotificationContent extends NotificationMessageContent {
    groupId = '';
}