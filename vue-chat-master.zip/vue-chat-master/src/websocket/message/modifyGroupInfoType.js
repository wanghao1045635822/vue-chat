export default class ModifyGroupInfoType {
    static Modify_Group_Name = 0;
    static Modify_Group_Portrait = 1;
    static Modify_Group_Extra = 2;
}