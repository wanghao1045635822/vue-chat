export default class MyInfotype {
    static Modify_DisplayName = 0;
    static Modify_Portrait = 1;
    static Modify_Gender = 2;
    static Modify_Mobile = 3;
    static Modify_Email = 4;
    static Modify_Address = 5;
    static Modify_Company = 6;
    static Modify_Social = 7;
    static Modify_Extra = 8;
}