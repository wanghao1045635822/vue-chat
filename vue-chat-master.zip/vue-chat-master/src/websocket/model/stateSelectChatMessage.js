export default class StateSelectChateMessage{
    name = '';
    target;
    protoMessages = [];
}