export default class ConversationType {
    static Single = 0;
    static Group = 1;
    static ChatRoom = 2;
    static Channel = 3;
}