export default class GroupMemberType {
    static Normal = 0;
    static Manager = 1;
    static Owner = 2;
}