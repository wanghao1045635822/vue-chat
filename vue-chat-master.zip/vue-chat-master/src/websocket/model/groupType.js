export default class GroupType {
    static Normal = 0;
    static Free = 1;
    static Restricted = 2;
}