export default class UnreadCount {
    // 单聊未读数
    unread = 0;
    // 群聊@数
    unreadMention = 0;
    // 群聊@All数
    unreadMentionAll = 0;
}