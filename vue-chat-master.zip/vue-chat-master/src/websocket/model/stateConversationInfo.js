export default class StateConversationInfo{
    name;
    img;
    //ProtoConversationInfo
    conversationInfo = {};
}